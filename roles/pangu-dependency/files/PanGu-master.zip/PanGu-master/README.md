# PanGu

使用方法：
1. 修改pom.xml中jnetpcap依赖路径，改为{path-to-your-pangu}/libs/jnetpcap.jar
2. 运行时需要加上  --Djava.library.path={path-to-your-pangu}/libs/linux64 -Djava.ext.dirs={path-to-your-pangu}/libs/linux64
